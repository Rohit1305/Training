package com.aurionpro.model;

import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable {
	private int employeeID;
	private String employeeName;
	private String job;
	private int managerId;
	private Date joiningDate;
	private double salary;
	private double commision;
	private int departmentNo;

	public Employee(int employeeID, String employeeName, String job, int managerId, Date joiningDate, double salary,
			double commision, int departmentNo) {
		this.employeeID = employeeID;
		this.employeeName = employeeName;
		this.job = job;
		this.managerId = managerId;
		this.joiningDate = joiningDate;
		this.salary = salary;
		this.commision = commision;
		this.departmentNo = departmentNo;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getCommision() {
		return commision;
	}

	public void setCommision(double commision) {
		this.commision = commision;
	}

	public int getDepartmentNo() {
		return departmentNo;
	}

	public void setDepartmentNo(int departmentNo) {
		this.departmentNo = departmentNo;
	}

	@Override
	public String toString() {
		return "\n Employee [employeeID=" + employeeID + ", employeeName=" + employeeName + ", job=" + job + ", managerId="
				+ managerId + ", joiningDate=" + joiningDate + ", salary=" + salary + ", commision=" + commision
				+ ", departmentNo=" + departmentNo + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(commision);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + departmentNo;
		result = prime * result + employeeID;
		result = prime * result + ((employeeName == null) ? 0 : employeeName.hashCode());
		result = prime * result + ((job == null) ? 0 : job.hashCode());
		result = prime * result + ((joiningDate == null) ? 0 : joiningDate.hashCode());
		result = prime * result + managerId;
		temp = Double.doubleToLongBits(salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (Double.doubleToLongBits(commision) != Double.doubleToLongBits(other.commision))
			return false;
		if (departmentNo != other.departmentNo)
			return false;
		if (employeeID != other.employeeID)
			return false;
		if (employeeName == null) {
			if (other.employeeName != null)
				return false;
		} else if (!employeeName.equals(other.employeeName))
			return false;
		if (job == null) {
			if (other.job != null)
				return false;
		} else if (!job.equals(other.job))
			return false;
		if (joiningDate == null) {
			if (other.joiningDate != null)
				return false;
		} else if (!joiningDate.equals(other.joiningDate))
			return false;
		if (managerId != other.managerId)
			return false;
		if (Double.doubleToLongBits(salary) != Double.doubleToLongBits(other.salary))
			return false;
		return true;
	}
	
	

}
